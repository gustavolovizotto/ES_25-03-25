public abstract class Pessoa{

	private int cpf;
	private String nome;
	private Endereco ender;

//========================================================

	public Pessoa(){
		cpf = 0;
		nome = "";
		ender = new Endereco();
	}

	public abstract void impDados();

//========================================================
	public Endereco getEnder(){
		return ender;
	}

	public void setEnder(Endereco ender){
		this.ender  = ender;
	}
	
	public int getCpf(){
		return cpf;
	}

	public String getNome(){
		return nome;
	}

	public void setCpf(int cpf){
		this.cpf = cpf;
	}

	public void setNome(String nome){
		this.nome = nome;
	}
	

}//fim da classe