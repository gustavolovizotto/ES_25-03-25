public class TstHer{

	public static void main(String arg[]){ //classloader
		


		Pessoa pes1;               //declaração
		pes1 = new Prof();      //instanciação

		Prof prof = new Prof();
	

	}//fim do main

}//fim da classe



	