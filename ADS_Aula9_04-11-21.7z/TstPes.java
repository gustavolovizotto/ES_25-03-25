public class TstPes{

	public static void main(String arg[]){ //classloader

		Pessoa p1 = new Pessoa();

		p1.setCpf(1);
		p1.setNome("Ruah");
		p1.getEnder().setRua("das Flores");
		p1.getEnder().setNum(10);
	
		Pessoa p2 = new Pessoa(p1);
		

		System.out.println("\nCPF - P1...: "+ p1.getCpf());
		System.out.println("NOME - P1..: "+ p1.getNome());
		System.out.println("RUA - P1..: "+ p1.getEnder().getRua());
		System.out.println("NUMERO - P1..: "+ p1.getEnder().getNum());

		System.out.println("\n\nCPF - P2...: "+ p2.getCpf());
		System.out.println("NOME - P2..: "+ p2.getNome());
		System.out.println("RUA - P2..: "+ p2.getEnder().getRua());
		System.out.println("NUMERO - P2..: "+ p2.getEnder().getNum());

		p2.setCpf(16);
		p2.setNome("Jesus");
		p2.getEnder().setRua("do Coracao");
		p2.getEnder().setNum(25);


		System.out.println("\nCPF - P1...: "+ p1.getCpf());
		System.out.println("NOME - P1..: "+ p1.getNome());
		System.out.println("RUA - P1..: "+ p1.getEnder().getRua());
		System.out.println("NUMERO - P1..: "+ p1.getEnder().getNum());

		System.out.println("\n\nCPF - P2...: "+ p2.getCpf());
		System.out.println("NOME - P2..: "+ p2.getNome());
		System.out.println("RUA - P2..: "+ p2.getEnder().getRua());
		System.out.println("NUMERO - P2..: "+ p2.getEnder().getNum());

		System.out.println("\n\nEndereco de P1..: "+ p1);
		System.out.println("\nEndereco de P2..: "+ p2);


	



	}//fim do main

}//fim da classe












/*	Leitura l = new Leitura();

		p1.setCpf(Integer.parseInt(l.entDados("\nInforme o CPF: ")));
		p1.setNome(l.entDados("Informe o NOME: "));

		p1.getEnder().setRua(l.entDados("Informe a RUA: "));
		p1.getEnder().setNum(Integer.parseInt(l.entDados("\nInforme o NUMERO: ")));


		System.out.println("\nCPF...: "+ p1.getCpf());
		System.out.println("NOME..: "+ p1.getNome());
		System.out.println("RUA..: "+ p1.getEnder().getRua());
		System.out.println("NUMERO..: "+ p1.getEnder().getNum());


*/		