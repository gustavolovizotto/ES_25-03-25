public class Prof extends Pessoa{

	private int sal;
	private String titulo;

//==================================================

	public void impDados(){
		System.out.println("\nMetodo impDados DEFAULT da classe-filha Prof");
	}

	//public void call_Imp_Mae(){

	//	cpf = 10;
	//	System.out.println("\n getCPF PROTECTED VALE: "+ getCpf());
	//	super.impDados();
	//}

	public Prof(){
		sal = 0;
		titulo ="";
		//super();
	}


//==================================================

	
	public int getSal(){
		return sal;
	}

	public String getTitulo(){
		return titulo;
	}

	public void setSal(int sal){
		this.sal = sal;
	}

	public void setTitulo(String titulo){
		this.titulo = titulo;
	}
	

}//fim da classe