public abstract class Pessoa{

	protected int doc;
	
	private int cpf;
	private String nome;
	private Endereco ender;
	
//======================================	

	public abstract void calcRenda();  //{} erro

//======================================

	public Pessoa(){
		cpf = 0;
		nome = "";
		ender = new Endereco();
	}
	
	public Pessoa(int cpf, String nome, Endereco ender){
		this.cpf   = cpf;
		this.nome  = nome;
		this.ender = ender;
	}
	
// ======================================

public void impDados(){
	System.out.println("\n impDados() Default da classe-mae Pessoa");
}

//======================================

	public Endereco getEnder(){
		return ender;
	}
	
	public void setEnder(Endereco ender){
			this.ender = ender;
	}
	
	public int getCpf(){
		return cpf;
	}
	
	public int getDoc(){
		return doc;
	}

	public String getNome(){
		return nome;
	}
	

	public void setCpf(int cpf){
		this.cpf = cpf;
	}
	
		public void setDoc(int doc){
		this.doc = doc;
	}

	public void setNome(String nome){
		this.nome = nome;
	}


}